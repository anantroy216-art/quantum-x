import './globals.css';
import type { Metadata } from 'next';
import { Inter, Space_Grotesk } from 'next/font/google';

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-sans',
  display: 'swap',
});

const spaceGrotesk = Space_Grotesk({
  subsets: ['latin'],
  variable: '--font-display',
  display: 'swap',
  weight: ['400', '500', '600', '700'],
});

export const metadata: Metadata = {
  metadataBase: new URL('https://quantumx.com'),
  title: 'Quantum X — Premium Digital Gift Cards, Gaming Cards & Vouchers',
  description:
    'Quantum X delivers genuine digital gift cards, gaming cards, prepaid cards, and digital vouchers with instant delivery, secure payment, and 24/7 support.',
  keywords: [
    'digital gift cards',
    'gaming cards',
    'prepaid cards',
    'digital vouchers',
    'Quantum X',
  ],
  openGraph: {
    title: 'Quantum X — Premium Digital Products',
    description:
      'Genuine digital gift cards, gaming cards, prepaid cards, and vouchers delivered instantly.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Quantum X — Premium Digital Products',
    description:
      'Genuine digital gift cards, gaming cards, prepaid cards, and vouchers delivered instantly.',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark">
      <body
        className={`${inter.variable} ${spaceGrotesk.variable} font-sans antialiased`}
      >
        {children}
      </body>
    </html>
  );
}
