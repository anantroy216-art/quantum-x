'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import {
  SearchIcon,
  BagIcon,
  UserIcon,
  MenuIcon,
  CloseIcon,
  BoltIcon,
} from '@/components/icons';
import { cn } from '@/lib/utils';

const navLinks = [
  { label: 'Home', href: '#home' },
  { label: 'Shop', href: '#categories' },
  { label: 'Categories', href: '#categories' },
  { label: 'About', href: '#why-us' },
  { label: 'FAQ', href: '#faq' },
  { label: 'Contact', href: '#contact' },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [open]);

  return (
    <>
      <header
        className={cn(
          'fixed inset-x-0 top-0 z-50 transition-all duration-500',
          scrolled
            ? 'glass-strong border-b border-white/5 py-3'
            : 'border-b border-transparent py-5'
        )}
      >
        <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 sm:px-8">
          {/* Logo */}
          <Link href="#home" className="group flex items-center gap-2.5">
            <span className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-electric-gradient shadow-glow transition-transform duration-300 group-hover:scale-105">
              <BoltIcon className="h-4 w-4 text-white" />
            </span>
            <span className="font-display text-lg font-bold tracking-tight text-white">
              Quantum<span className="text-electric-bright"> X</span>
            </span>
          </Link>

          {/* Desktop links */}
          <ul className="hidden items-center gap-1 lg:flex">
            {navLinks.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className="relative rounded-lg px-4 py-2 text-sm font-medium text-white/70 transition-colors duration-300 hover:text-white"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>

          {/* Actions */}
          <div className="flex items-center gap-1.5">
            <button
              aria-label="Search"
              className="flex h-10 w-10 items-center justify-center rounded-xl text-white/70 transition-all duration-300 hover:bg-white/5 hover:text-white active:scale-90"
            >
              <SearchIcon className="h-[18px] w-[18px]" />
            </button>
            <button
              aria-label="Account"
              className="hidden h-10 w-10 items-center justify-center rounded-xl text-white/70 transition-all duration-300 hover:bg-white/5 hover:text-white active:scale-90 sm:flex"
            >
              <UserIcon className="h-[18px] w-[18px]" />
            </button>
            <button
              aria-label="Cart"
              className="relative flex h-10 w-10 items-center justify-center rounded-xl text-white/70 transition-all duration-300 hover:bg-white/5 hover:text-white active:scale-90"
            >
              <BagIcon className="h-[18px] w-[18px]" />
              <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-electric-gradient text-[10px] font-bold text-white">
                2
              </span>
            </button>

            {/* Mobile toggle */}
            <button
              aria-label="Menu"
              onClick={() => setOpen((v) => !v)}
              className="flex h-10 w-10 items-center justify-center rounded-xl text-white transition-all duration-300 hover:bg-white/5 active:scale-90 lg:hidden"
            >
              {open ? (
                <CloseIcon className="h-5 w-5" />
              ) : (
                <MenuIcon className="h-5 w-5" />
              )}
            </button>
          </div>
        </nav>
      </header>

      {/* Mobile menu */}
      <div
        className={cn(
          'fixed inset-0 z-40 lg:hidden',
          open ? 'pointer-events-auto' : 'pointer-events-none'
        )}
      >
        <div
          className={cn(
            'absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity duration-300',
            open ? 'opacity-100' : 'opacity-0'
          )}
          onClick={() => setOpen(false)}
        />
        <div
          className={cn(
            'absolute right-0 top-0 h-full w-[82%] max-w-sm glass-strong px-6 pb-8 pt-24 transition-transform duration-500 ease-out',
            open ? 'translate-x-0' : 'translate-x-full'
          )}
        >
          <ul className="flex flex-col gap-1">
            {navLinks.map((link, i) => (
              <li
                key={link.href}
                style={{ transitionDelay: `${open ? i * 40 : 0}ms` }}
                className={cn(
                  'transition-all duration-500',
                  open ? 'translate-x-0 opacity-100' : 'translate-x-6 opacity-0'
                )}
              >
                <a
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className="block rounded-xl px-4 py-3.5 text-lg font-medium text-white/80 transition-colors hover:bg-white/5 hover:text-white"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
          <div className="mt-8 flex flex-col gap-3">
            <button className="flex items-center justify-center gap-2 rounded-xl bg-white/5 px-4 py-3 text-sm font-medium text-white/80 transition-colors hover:bg-white/10">
              <UserIcon className="h-4 w-4" /> My Account
            </button>
            <button className="rounded-xl bg-electric-gradient px-4 py-3 text-sm font-semibold text-white shadow-glow transition-transform active:scale-95">
              Start Shopping
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
