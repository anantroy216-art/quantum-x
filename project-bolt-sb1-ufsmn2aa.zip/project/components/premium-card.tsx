'use client';

import { cn } from '@/lib/utils';

type CardVariant = 'obsidian' | 'platinum' | 'electric';

const variantStyles: Record<
  CardVariant,
  {
    surface: string;
    sheen: string;
    text: string;
    subtext: string;
    chip: string;
  }
> = {
  obsidian: {
    surface:
      'bg-[linear-gradient(135deg,#1a1a1f_0%,#0a0a0d_45%,#16161c_100%)]',
    sheen: 'from-white/25 via-white/0 to-white/10',
    text: 'text-white',
    subtext: 'text-white/55',
    chip: 'from-amber-200/90 via-amber-100/70 to-yellow-300/90',
  },
  platinum: {
    surface:
      'bg-[linear-gradient(135deg,#e8e9ec_0%,#b8bcc4_45%,#d4d6dc_100%)]',
    sheen: 'from-white/70 via-white/10 to-white/40',
    text: 'text-zinc-900',
    subtext: 'text-zinc-700/70',
    chip: 'from-amber-300 via-amber-200 to-yellow-400',
  },
  electric: {
    surface:
      'bg-[linear-gradient(135deg,#0a1a3a_0%,#0d3a7a_45%,#0066ff_100%)]',
    sheen: 'from-cyan-200/40 via-white/0 to-blue-300/30',
    text: 'text-white',
    subtext: 'text-white/60',
    chip: 'from-amber-200 via-amber-100 to-yellow-300',
  },
};

export function PremiumCard({
  variant = 'obsidian',
  className,
  holder = 'QUANTUM X',
  number = '4291 7203 8814 0267',
  expiry = '12/29',
  brand = 'Quantum',
  tier = 'INFINITE',
  style,
}: {
  variant?: CardVariant;
  className?: string;
  holder?: string;
  number?: string;
  expiry?: string;
  brand?: string;
  tier?: string;
  style?: React.CSSProperties;
}) {
  const v = variantStyles[variant];
  const last4 = number.replace(/\D/g, '').slice(-4).padStart(4, '0');
  const maskedNumber = `•••• •••• •••• ${last4}`;
  return (
    <div
      style={style}
      className={cn(
        'group relative aspect-[1.586/1] w-full select-none rounded-2xl p-6 shadow-[0_30px_80px_-20px_rgba(0,0,0,0.7)] transition-transform duration-700 will-change-transform',
        v.surface,
        className
      )}
    >
      {/* Brushed metal texture */}
      <div
        className="pointer-events-none absolute inset-0 rounded-2xl opacity-[0.18] mix-blend-overlay"
        style={{
          backgroundImage:
            'repeating-linear-gradient(75deg, rgba(255,255,255,0.6) 0px, rgba(255,255,255,0) 1px, rgba(255,255,255,0) 2px, rgba(255,255,255,0.4) 3px)',
        }}
      />
      {/* Glass reflection sweep */}
      <div
        className={cn(
          'pointer-events-none absolute inset-0 rounded-2xl bg-gradient-to-br opacity-60',
          v.sheen
        )}
      />
      {/* Top gloss highlight */}
      <div className="pointer-events-none absolute inset-x-0 top-0 h-1/3 rounded-t-2xl bg-gradient-to-b from-white/20 to-transparent" />
      {/* Edge light */}
      <div className="pointer-events-none absolute inset-0 rounded-2xl ring-1 ring-inset ring-white/10" />

      {/* Content */}
      <div className="relative flex h-full flex-col justify-between">
        {/* Top row */}
        <div className="flex items-start justify-between">
          <div className="flex flex-col gap-3">
            {/* EMV chip */}
            <div
              className={cn(
                'relative h-8 w-11 overflow-hidden rounded-md bg-gradient-to-br shadow-inner',
                v.chip
              )}
            >
              <div className="absolute inset-0 bg-[repeating-linear-gradient(90deg,rgba(0,0,0,0.25)_0,rgba(0,0,0,0.25)_1px,transparent_1px,transparent_3px)]" />
              <div className="absolute inset-x-1 top-1/2 h-px -translate-y-1/2 bg-black/30" />
            </div>
            {/* Contactless icon */}
            <ContactlessIcon className={cn('h-5 w-5', v.text)} />
          </div>

          {/* Brand mark */}
          <div className="text-right">
            <p
              className={cn(
                'font-display text-lg font-bold tracking-tight leading-none',
                v.text
              )}
            >
              {brand}
            </p>
            <p
              className={cn(
                'mt-1 text-[10px] font-semibold uppercase tracking-[0.25em]',
                v.subtext
              )}
            >
              {tier}
            </p>
          </div>
        </div>

        {/* Center hologram */}
        <div className="flex justify-center">
          <div className="relative h-9 w-9 rounded-full bg-gradient-to-br from-amber-200/40 via-cyan-200/30 to-fuchsia-200/40 opacity-70 blur-[1px]">
            <div className="absolute inset-1 rounded-full bg-gradient-to-tr from-transparent via-white/30 to-transparent" />
          </div>
        </div>

        {/* Number */}
        <div>
          <p
            className={cn(
              'font-mono text-[15px] tracking-[0.18em] sm:text-base',
              v.text
            )}
            style={{ textShadow: '0 1px 2px rgba(0,0,0,0.3)' }}
          >
            {maskedNumber}
          </p>
          <div className="mt-3 flex items-end justify-between">
            <div>
              <p
                className={cn(
                  'text-[9px] uppercase tracking-widest',
                  v.subtext
                )}
              >
                Card Holder
              </p>
              <p
                className={cn(
                  'mt-0.5 text-xs font-semibold tracking-wide',
                  v.text
                )}
              >
                ••••••••
              </p>
            </div>
            <div className="text-right">
              <p
                className={cn(
                  'text-[9px] uppercase tracking-widest',
                  v.subtext
                )}
              >
                Expires
              </p>
              <p
                className={cn(
                  'mt-0.5 text-xs font-semibold tracking-wide',
                  v.text
                )}
              >
                ••/••
              </p>
            </div>
            {/* Network mark */}
            <NetworkMark className={cn('h-7', v.text)} />
          </div>
        </div>
      </div>
    </div>
  );
}

function ContactlessIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      className={className}
      aria-hidden="true"
    >
      <path
        d="M8.5 8.5a5 5 0 010 7M12 5.5a9 9 0 010 13M15.5 8.5a5 5 0 010 7"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        opacity="0.85"
      />
    </svg>
  );
}

function NetworkMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 24" className={className} aria-hidden="true">
      <circle cx="14" cy="12" r="9" fill="currentColor" opacity="0.95" />
      <circle
        cx="26"
        cy="12"
        r="9"
        fill="currentColor"
        opacity="0.55"
        style={{ mixBlendMode: 'multiply' }}
      />
    </svg>
  );
}
