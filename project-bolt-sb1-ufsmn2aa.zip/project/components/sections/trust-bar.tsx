'use client';

import {
  BoltIcon,
  ShieldIcon,
  BadgeIcon,
  HeadsetIcon,
  StoreIcon,
  RefreshIcon,
} from '@/components/icons';
import { trustBadges } from '@/lib/data';
import { Reveal } from '@/components/reveal';

const icons = [
  BoltIcon,
  ShieldIcon,
  BadgeIcon,
  HeadsetIcon,
  StoreIcon,
  RefreshIcon,
];

export function TrustBar() {
  return (
    <section className="relative border-y border-white/5 bg-white/[0.02] py-10">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid grid-cols-2 gap-x-6 gap-y-8 md:grid-cols-3 lg:grid-cols-6">
          {trustBadges.map((badge, i) => {
            const Icon = icons[i];
            return (
              <Reveal
                key={badge.label}
                delay={i * 60}
                className="group flex flex-col items-center text-center"
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-electric-bright transition-all duration-300 group-hover:scale-110 group-hover:border-electric/40 group-hover:bg-electric/10">
                  <Icon className="h-5 w-5" />
                </span>
                <p className="mt-3 text-sm font-semibold text-white">
                  {badge.label}
                </p>
                <p className="mt-0.5 text-xs text-white/50">
                  {badge.description}
                </p>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
