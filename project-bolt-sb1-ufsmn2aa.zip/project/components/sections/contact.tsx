'use client';

import { TelegramIcon, ArrowRightIcon } from '@/components/icons';
import { Reveal } from '@/components/reveal';

const TELEGRAM_URL = 'https://t.me/QuantummXofficial';

export function Contact() {
  return (
    <section
      id="contact"
      className="relative overflow-hidden border-t border-white/5 bg-white/[0.02] py-24 sm:py-32"
    >
      <div className="absolute -right-40 top-0 h-[400px] w-[400px] rounded-full bg-electric/10 blur-[120px]" />
      <div className="absolute -left-40 bottom-0 h-[360px] w-[360px] rounded-full bg-sky-500/10 blur-[120px]" />

      <div className="relative mx-auto max-w-4xl px-5 sm:px-8">
        <Reveal>
          <div className="mx-auto max-w-2xl text-center">
            <span className="inline-flex items-center gap-2 rounded-full border border-electric/30 bg-electric/10 px-3 py-1 text-xs font-medium text-electric-bright">
              Contact
            </span>
            <h2 className="mt-4 font-display text-4xl font-bold tracking-tight text-white sm:text-5xl">
              Let&apos;s talk
            </h2>
            <p className="mt-4 text-white/50">
              Have a question about an order, a product, or anything else? Our
              team is here 24/7 and typically replies within a few hours.
            </p>
          </div>
        </Reveal>

        <Reveal delay={120}>
          <div className="group relative mt-12 overflow-hidden rounded-3xl border border-white/10 bg-white/[0.04] p-8 backdrop-blur-xl transition-all duration-500 hover:border-electric/40 hover:bg-white/[0.06] sm:p-12">
            <div className="absolute inset-0 bg-gradient-to-br from-electric/10 via-transparent to-sky-500/10 opacity-0 transition-opacity duration-500 group-hover:opacity-100" />

            <div className="relative flex flex-col items-center gap-8 text-center sm:flex-row sm:items-center sm:gap-10 sm:text-left">
              <span className="flex h-20 w-20 shrink-0 items-center justify-center rounded-2xl border border-electric/30 bg-electric/10 text-electric-bright shadow-glow transition-transform duration-500 group-hover:scale-105">
                <TelegramIcon className="h-10 w-10" />
              </span>

              <div className="flex-1">
                <h3 className="font-display text-2xl font-bold tracking-tight text-white sm:text-3xl">
                  Telegram Community
                </h3>
                <p className="mt-3 max-w-lg text-white/50">
                  Join our official Telegram channel for updates, new products,
                  announcements, and customer support.
                </p>
              </div>

              <a
                href={TELEGRAM_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="group/btn relative inline-flex w-full items-center justify-center gap-2.5 overflow-hidden rounded-2xl border border-electric/40 bg-electric/15 px-7 py-4 text-base font-semibold text-white shadow-glow backdrop-blur-md transition-all duration-300 hover:scale-[1.03] hover:bg-electric/25 active:scale-95 sm:w-auto"
              >
                <TelegramIcon className="h-5 w-5" />
                <span className="relative z-10">Join Telegram</span>
                <ArrowRightIcon className="relative z-10 h-5 w-5 transition-transform duration-300 group-hover/btn:translate-x-1" />
                <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/20 to-transparent transition-transform duration-700 group-hover/btn:translate-x-full" />
              </a>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
