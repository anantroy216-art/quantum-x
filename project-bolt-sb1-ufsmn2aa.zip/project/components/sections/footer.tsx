'use client';

import Link from 'next/link';
import {
  BoltIcon,
  TwitterIcon,
  InstagramIcon,
  FacebookIcon,
  LinkedinIcon,
  YoutubeIcon,
  ArrowRightIcon,
} from '@/components/icons';
import { useState } from 'react';

const footerLinks = {
  Shop: [
    { label: 'Gift Cards', href: '#categories' },
    { label: 'Gaming Cards', href: '#categories' },
    { label: 'Prepaid Cards', href: '#categories' },
    { label: 'Digital Vouchers', href: '#categories' },
    { label: 'Subscriptions', href: '#categories' },
  ],
  Company: [
    { label: 'About Us', href: '#why-us' },
    { label: 'Contact', href: '#contact' },
    { label: 'FAQ', href: '#faq' },
    { label: 'Careers', href: '#' },
  ],
  Legal: [
    { label: 'Privacy Policy', href: '#' },
    { label: 'Terms & Conditions', href: '#' },
    { label: 'Refund Policy', href: '#' },
    { label: 'Cookie Policy', href: '#' },
  ],
};

const socials = [TwitterIcon, InstagramIcon, FacebookIcon, LinkedinIcon, YoutubeIcon];

export function Footer() {
  const [subscribed, setSubscribed] = useState(false);

  return (
    <footer className="relative overflow-hidden border-t border-white/5 bg-background">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-electric/50 to-transparent" />

      {/* Newsletter */}
      <div className="border-b border-white/5">
        <div className="mx-auto max-w-7xl px-5 py-16 sm:px-8">
          <div className="flex flex-col items-start justify-between gap-8 lg:flex-row lg:items-center">
            <div className="max-w-md">
              <h3 className="font-display text-2xl font-bold text-white sm:text-3xl">
                Join the Quantum X circle
              </h3>
              <p className="mt-2 text-white/50">
                Get exclusive deals, early access to new products and
                member-only discounts — straight to your inbox.
              </p>
            </div>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                setSubscribed(true);
                setTimeout(() => setSubscribed(false), 3500);
              }}
              className="flex w-full max-w-md items-center gap-2"
            >
              <input
                type="email"
                required
                placeholder="Enter your email"
                className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3.5 text-sm text-white placeholder:text-white/30 outline-none transition-colors focus:border-electric/50 focus:bg-white/[0.07]"
              />
              <button
                type="submit"
                className="group flex shrink-0 items-center gap-1.5 rounded-xl bg-electric-gradient px-5 py-3.5 text-sm font-semibold text-white shadow-glow transition-transform duration-300 active:scale-95"
              >
                {subscribed ? 'Subscribed!' : 'Subscribe'}
                {!subscribed && (
                  <ArrowRightIcon className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
                )}
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Main footer */}
      <div className="mx-auto max-w-7xl px-5 py-16 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-12">
          {/* Brand */}
          <div className="lg:col-span-4">
            <Link href="#home" className="group flex items-center gap-2.5">
              <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-electric-gradient shadow-glow">
                <BoltIcon className="h-4 w-4 text-white" />
              </span>
              <span className="font-display text-lg font-bold tracking-tight text-white">
                Quantum<span className="text-electric-bright"> X</span>
              </span>
            </Link>
            <p className="mt-4 max-w-xs text-sm leading-relaxed text-white/50">
              The premium destination for genuine digital gift cards, gaming
              cards, prepaid cards and vouchers — delivered instantly,
              worldwide.
            </p>
            <div className="mt-6 flex gap-2">
              {socials.map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  aria-label="Social link"
                  className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-white/60 transition-all duration-300 hover:border-electric/40 hover:bg-electric/10 hover:text-electric-bright active:scale-90"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          <div className="grid grid-cols-2 gap-8 sm:grid-cols-3 lg:col-span-8">
            {Object.entries(footerLinks).map(([heading, links]) => (
              <div key={heading}>
                <h4 className="text-sm font-semibold uppercase tracking-wider text-white/80">
                  {heading}
                </h4>
                <ul className="mt-4 flex flex-col gap-3">
                  {links.map((link) => (
                    <li key={link.label}>
                      <a
                        href={link.href}
                        className="text-sm text-white/50 transition-colors duration-300 hover:text-electric-bright"
                      >
                        {link.label}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-white/5 pt-8 sm:flex-row">
          <p className="text-sm text-white/40">
            © {new Date().getFullYear()} Quantum X. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <span className="text-xs text-white/40">
              Secure payments powered by Quantum Pay
            </span>
            <div className="flex gap-2">
              <span className="rounded-md border border-white/10 bg-white/5 px-2.5 py-1 text-[10px] font-medium text-white/60">
                VISA
              </span>
              <span className="rounded-md border border-white/10 bg-white/5 px-2.5 py-1 text-[10px] font-medium text-white/60">
                MASTERCARD
              </span>
              <span className="rounded-md border border-white/10 bg-white/5 px-2.5 py-1 text-[10px] font-medium text-white/60">
                APPLE PAY
              </span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
