'use client';

import {
  BoltIcon,
  ShieldIcon,
  BadgeIcon,
  ClockIcon,
  GlobeIcon,
  HeadsetIcon,
} from '@/components/icons';
import { Reveal } from '@/components/reveal';

const reasons = [
  {
    icon: BoltIcon,
    title: 'Instant Delivery',
    description:
      'Codes and digital entitlements are delivered to your inbox within seconds of a successful payment — no waiting, no delays.',
  },
  {
    icon: ShieldIcon,
    title: 'Secure & Encrypted',
    description:
      'Every transaction is protected by bank-grade encryption and processed through PCI-DSS compliant payment gateways.',
  },
  {
    icon: BadgeIcon,
    title: '100% Genuine Products',
    description:
      'All products are sourced directly from official distributors and verified partners. Every code is guaranteed authentic.',
  },
  {
    icon: ClockIcon,
    title: '24/7 Support',
    description:
      'Our support team is available around the clock to help with redemptions, replacements, and any questions you have.',
  },
  {
    icon: GlobeIcon,
    title: 'Global Coverage',
    description:
      'We serve customers in over 90 countries with region-specific gift cards, gaming cards, and digital vouchers.',
  },
  {
    icon: HeadsetIcon,
    title: 'Money Back Policy',
    description:
      'If a code fails to redeem, we replace it or refund you in full. Protected purchases, every single time.',
  },
];

const stats = [
  { value: '50K+', label: 'Happy customers' },
  { value: '120K+', label: 'Orders delivered' },
  { value: '4.9/5', label: 'Average rating' },
  { value: '90+', label: 'Countries served' },
];

export function WhyChooseUs() {
  return (
    <section id="why-us" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-12 lg:gap-16">
          {/* Left intro */}
          <div className="lg:col-span-5">
            <Reveal>
              <span className="inline-flex items-center gap-2 rounded-full border border-electric/30 bg-electric/10 px-3 py-1 text-xs font-medium text-electric-bright">
                Why Quantum X
              </span>
              <h2 className="mt-4 font-display text-4xl font-bold tracking-tight text-white sm:text-5xl">
                Built for trust,
                <br />
                designed for speed.
              </h2>
              <p className="mt-4 max-w-md text-white/50">
                We obsess over every detail — from sourcing genuine products to
                delivering them in seconds — so you can shop with total
                confidence.
              </p>
            </Reveal>

            <Reveal delay={150} className="mt-10 grid grid-cols-2 gap-5">
              {stats.map((stat) => (
                <div
                  key={stat.label}
                  className="rounded-2xl border border-white/10 bg-white/[0.03] p-5"
                >
                  <p className="font-display text-3xl font-bold text-gradient-blue">
                    {stat.value}
                  </p>
                  <p className="mt-1 text-sm text-white/50">{stat.label}</p>
                </div>
              ))}
            </Reveal>
          </div>

          {/* Right reasons grid */}
          <div className="lg:col-span-7">
            <div className="grid gap-4 sm:grid-cols-2">
              {reasons.map((reason, i) => {
                const Icon = reason.icon;
                return (
                  <Reveal
                    key={reason.title}
                    delay={i * 80}
                    className="group rounded-2xl border border-white/10 bg-white/[0.03] p-6 transition-all duration-500 hover:border-electric/30 hover:bg-white/[0.05]"
                  >
                    <span className="flex h-12 w-12 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-electric-bright transition-all duration-500 group-hover:scale-110 group-hover:border-electric/40 group-hover:bg-electric/10">
                      <Icon className="h-5 w-5" />
                    </span>
                    <h3 className="mt-5 font-display text-lg font-semibold text-white">
                      {reason.title}
                    </h3>
                    <p className="mt-2 text-sm leading-relaxed text-white/50">
                      {reason.description}
                    </p>
                  </Reveal>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
