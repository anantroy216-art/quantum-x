'use client';

import Link from 'next/link';
import {
  ArrowRightIcon,
  SparkleIcon,
  StarIcon,
  ShieldIcon,
  BoltIcon,
  PlayIcon,
} from '@/components/icons';
import { PremiumCard } from '@/components/premium-card';

export function Hero() {
  return (
    <section
      id="home"
      className="relative flex min-h-screen items-center overflow-hidden pt-24"
    >
      {/* Background layers */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-grid mask-fade-b opacity-30" />
        <div className="absolute left-1/2 top-0 h-[600px] w-[900px] -translate-x-1/2 rounded-full bg-electric/15 opacity-50 blur-[140px]" />
        <div className="absolute -left-40 top-1/3 h-[400px] w-[400px] rounded-full bg-electric-bright/10 blur-[120px] animate-glow-pulse" />
        <div className="absolute right-0 top-1/4 h-[500px] w-[500px] rounded-full bg-electric-deep/10 blur-[140px]" />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background" />
      </div>

      <div className="mx-auto w-full max-w-7xl px-5 sm:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-12 lg:gap-8">
          {/* Left: copy */}
          <div className="lg:col-span-6">
            <div className="animate-fade-up inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-1.5 text-xs font-medium text-white/80 backdrop-blur-md">
              <SparkleIcon className="h-3.5 w-3.5 text-electric-bright" />
              Trusted by 50,000+ customers worldwide
            </div>

            <h1
              className="animate-fade-up mt-6 font-display text-5xl font-bold leading-[1.05] tracking-tight text-white sm:text-6xl lg:text-7xl"
              style={{ animationDelay: '80ms' }}
            >
              The future of
              <br />
              <span className="text-gradient-blue animate-gradient">
                digital commerce.
              </span>
            </h1>

            <p
              className="animate-fade-up mt-6 max-w-xl text-lg leading-relaxed text-white/60"
              style={{ animationDelay: '160ms' }}
            >
              Genuine gift cards, gaming cards, prepaid cards and digital
              vouchers — sourced from official partners, secured by
              bank-grade encryption, and delivered to your inbox in seconds.
            </p>

            <div
              className="animate-fade-up mt-9 flex flex-wrap items-center gap-3"
              style={{ animationDelay: '240ms' }}
            >
              <Link
                href="#categories"
                className="group relative inline-flex items-center gap-2 overflow-hidden rounded-xl bg-electric-gradient px-7 py-3.5 text-sm font-semibold text-white shadow-glow transition-transform duration-300 hover:scale-[1.02] active:scale-95"
              >
                <span className="relative z-10">Get Started</span>
                <ArrowRightIcon className="relative z-10 h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
                <span className="absolute inset-0 -translate-x-full bg-white/20 transition-transform duration-500 group-hover:translate-x-full" />
              </Link>
              <Link
                href="#categories"
                className="inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/5 px-7 py-3.5 text-sm font-semibold text-white backdrop-blur-md transition-all duration-300 hover:bg-white/10 active:scale-95"
              >
                <PlayIcon className="h-3.5 w-3.5" /> Explore Products
              </Link>
            </div>

            {/* Mini stats */}
            <div
              className="animate-fade-up mt-12 flex flex-wrap items-center gap-x-8 gap-y-4"
              style={{ animationDelay: '320ms' }}
            >
              <div className="flex items-center gap-2">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <StarIcon
                      key={i}
                      className="h-4 w-4 text-electric-bright"
                    />
                  ))}
                </div>
                <span className="text-sm text-white/70">
                  4.9/5 from 12,000+ reviews
                </span>
              </div>
              <div className="flex items-center gap-2 text-sm text-white/70">
                <ShieldIcon className="h-4 w-4 text-electric-bright" />
                PCI-DSS compliant
              </div>
              <div className="flex items-center gap-2 text-sm text-white/70">
                <BoltIcon className="h-4 w-4 text-electric-bright" />
                Instant delivery
              </div>
            </div>
          </div>

          {/* Right: premium card stack */}
          <div className="lg:col-span-6">
            <div className="relative mx-auto max-w-md animate-fade-up [perspective:1500px] sm:max-w-lg">
              {/* Ambient glow */}
              <div className="absolute -inset-10 rounded-full bg-electric/20 opacity-50 blur-[100px]" />

              {/* Back card (platinum) */}
              <div
                className="relative z-10 mx-auto w-[78%] -translate-y-2 rotate-[-7deg] animate-float [animation-delay:1.2s]"
                style={{ transform: 'rotate(-7deg) translateY(8px)' }}
              >
                <PremiumCard
                  variant="platinum"
                  brand="Quantum"
                  tier="PLATINUM"
                  number="5312 8841 0093 2274"
                  holder="QUANTUM X"
                  expiry="08/28"
                />
              </div>

              {/* Front card (obsidian) */}
              <div
                className="relative z-20 -mt-[58%] mx-auto w-[88%] rotate-[4deg] animate-float"
                style={{ transform: 'rotate(4deg)' }}
              >
                <PremiumCard
                  variant="obsidian"
                  brand="Quantum"
                  tier="INFINITE"
                  number="4291 7203 8814 0267"
                  holder="QUANTUM X"
                  expiry="12/29"
                />
              </div>

              {/* Floating status pills */}
              <div className="absolute -left-4 top-1/2 z-30 hidden rounded-2xl border border-white/10 bg-black/60 px-4 py-3 shadow-premium backdrop-blur-xl sm:block animate-float [animation-delay:0.6s]">
                <div className="flex items-center gap-2.5">
                  <span className="flex h-8 w-8 items-center justify-center rounded-lg border border-emerald-500/30 bg-emerald-500/10">
                    <ShieldIcon className="h-4 w-4 text-emerald-400" />
                  </span>
                  <div>
                    <p className="text-xs font-semibold text-white">Verified</p>
                    <p className="text-[10px] text-white/50">Authentic code</p>
                  </div>
                </div>
              </div>

              <div className="absolute -right-2 bottom-10 z-30 hidden rounded-2xl border border-white/10 bg-black/60 px-4 py-3 shadow-premium backdrop-blur-xl sm:block animate-float [animation-delay:1.8s]">
                <div className="flex items-center gap-2.5">
                  <span className="flex h-8 w-8 items-center justify-center rounded-lg border border-electric/30 bg-electric/10">
                    <BoltIcon className="h-4 w-4 text-electric-bright" />
                  </span>
                  <div>
                    <p className="text-xs font-semibold text-white">Delivered</p>
                    <p className="text-[10px] text-white/50">in 28 seconds</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll cue */}
      <div className="absolute bottom-8 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 text-white/40 lg:flex">
        <span className="text-[11px] uppercase tracking-widest">Scroll</span>
        <span className="flex h-9 w-5 justify-center rounded-full border border-white/20 p-1">
          <span className="h-2 w-1 animate-bounce rounded-full bg-electric-bright" />
        </span>
      </div>
    </section>
  );
}
