'use client';

import { PlusIcon } from '@/components/icons';
import { faqItems } from '@/lib/data';
import { Reveal } from '@/components/reveal';
import { cn } from '@/lib/utils';
import { useState } from 'react';

export function FAQ() {
  const [openId, setOpenId] = useState<string | null>('f1');

  return (
    <section id="faq" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-3xl px-5 sm:px-8">
        <Reveal className="text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-electric/30 bg-electric/10 px-3 py-1 text-xs font-medium text-electric-bright">
            FAQ
          </span>
          <h2 className="mt-4 font-display text-4xl font-bold tracking-tight text-white sm:text-5xl">
            Frequently asked questions
          </h2>
          <p className="mt-3 text-white/50">
            Everything you need to know about buying digital products on
            Quantum X.
          </p>
        </Reveal>

        <Reveal delay={120} className="mt-12 flex flex-col gap-3">
          {faqItems.map((item) => {
            const isOpen = openId === item.id;
            return (
              <div
                key={item.id}
                className={cn(
                  'overflow-hidden rounded-2xl border bg-card/50 backdrop-blur-sm transition-all duration-300',
                  isOpen
                    ? 'border-electric/30 bg-card/80'
                    : 'border-white/10 hover:border-white/20'
                )}
              >
                <button
                  onClick={() => setOpenId(isOpen ? null : item.id)}
                  className="flex w-full items-center justify-between gap-4 px-5 py-5 text-left"
                >
                  <span className="font-display text-base font-semibold text-white">
                    {item.question}
                  </span>
                  <span
                    className={cn(
                      'flex h-7 w-7 shrink-0 items-center justify-center rounded-full border transition-all duration-300',
                      isOpen
                        ? 'rotate-45 border-electric/40 bg-electric/20 text-electric-bright'
                        : 'border-white/10 bg-white/5 text-white/60'
                    )}
                  >
                    <PlusIcon className="h-4 w-4" />
                  </span>
                </button>
                <div
                  className={cn(
                    'grid transition-all duration-300 ease-out',
                    isOpen
                      ? 'grid-rows-[1fr] opacity-100'
                      : 'grid-rows-[0fr] opacity-0'
                  )}
                >
                  <div className="overflow-hidden">
                    <p className="px-5 pb-5 text-sm leading-relaxed text-white/60">
                      {item.answer}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </Reveal>
      </div>
    </section>
  );
}
