'use client';

import { StarIcon, QuoteIcon } from '@/components/icons';
import Image from 'next/image';
import { testimonials } from '@/lib/data';
import { Reveal } from '@/components/reveal';

export function Testimonials() {
  return (
    <section className="relative overflow-hidden border-y border-white/5 bg-white/[0.02] py-24 sm:py-32">
      <div className="absolute left-1/2 top-0 h-[400px] w-[700px] -translate-x-1/2 rounded-full bg-electric/10 blur-[120px]" />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-electric/30 bg-electric/10 px-3 py-1 text-xs font-medium text-electric-bright">
            Testimonials
          </span>
          <h2 className="mt-4 font-display text-4xl font-bold tracking-tight text-white sm:text-5xl">
            Trusted by customers
            <br className="hidden sm:block" /> worldwide
          </h2>
          <p className="mt-3 text-white/50">
            Over 50,000 customers trust Quantum X for their digital product
            needs. Here is what some of them have to say.
          </p>
        </Reveal>

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {testimonials.map((t, i) => (
            <Reveal
              key={t.id}
              delay={i * 80}
              className="group relative flex flex-col rounded-2xl border border-white/10 bg-card/60 p-6 backdrop-blur-sm transition-all duration-500 hover:-translate-y-1.5 hover:border-electric/30 hover:shadow-premium"
            >
              <QuoteIcon className="h-7 w-7 text-electric/40" />
              <p className="mt-4 flex-1 text-sm leading-relaxed text-white/70">
                "{t.text}"
              </p>
              <div className="mt-5 flex items-center gap-1">
                {[...Array(5)].map((_, s) => (
                  <StarIcon
                    key={s}
                    className={`h-3.5 w-3.5 ${
                      s < t.rating
                        ? 'text-electric-bright'
                        : 'text-white/20'
                    }`}
                  />
                ))}
              </div>
              <div className="mt-4 flex items-center gap-3 border-t border-white/5 pt-4">
                <span className="relative h-10 w-10 overflow-hidden rounded-full border border-white/10">
                  <Image
                    src={t.avatar}
                    alt={t.name}
                    fill
                    sizes="40px"
                    className="object-cover"
                  />
                </span>
                <div>
                  <p className="text-sm font-semibold text-white">{t.name}</p>
                  <p className="text-xs text-white/40">{t.role}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
