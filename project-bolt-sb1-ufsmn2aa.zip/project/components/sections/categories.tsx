'use client';

import { ArrowUpRightIcon } from '@/components/icons';
import { categories } from '@/lib/data';
import { Reveal } from '@/components/reveal';
import { cn } from '@/lib/utils';

export function Categories() {
  return (
    <section
      id="categories"
      className="relative border-y border-white/5 bg-white/[0.02] py-24 sm:py-32"
    >
      <div className="absolute inset-0 -z-10 bg-dots opacity-30 mask-fade-b" />
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-electric/30 bg-electric/10 px-3 py-1 text-xs font-medium text-electric-bright">
            Categories
          </span>
          <h2 className="mt-4 font-display text-4xl font-bold tracking-tight text-white sm:text-5xl">
            Explore by category
          </h2>
          <p className="mt-3 text-white/50">
            From gaming to entertainment, find exactly what you need across our
            curated digital catalog.
          </p>
        </Reveal>

        <div className="mt-14 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {categories.map((cat, i) => {
            const Icon = cat.icon;
            return (
              <Reveal key={cat.id} delay={i * 70}>
                <a
                  href="#contact"
                  className={cn(
                    'group relative flex h-full flex-col justify-between overflow-hidden rounded-2xl border border-white/10 bg-gradient-to-br p-7 transition-all duration-500 hover:-translate-y-1.5 hover:border-electric/30 hover:shadow-premium',
                    cat.accent
                  )}
                >
                  <div className="absolute inset-0 bg-card/40" />
                  <div className="relative z-10 flex items-start justify-between">
                    <span className="flex h-14 w-14 items-center justify-center rounded-2xl border border-white/10 bg-white/5 text-electric-bright transition-all duration-500 group-hover:scale-110 group-hover:border-electric/40 group-hover:bg-electric/10">
                      <Icon className="h-6 w-6" />
                    </span>
                    <ArrowUpRightIcon className="h-5 w-5 text-white/30 transition-all duration-300 group-hover:translate-x-1 group-hover:-translate-y-1 group-hover:text-electric-bright" />
                  </div>
                  <div className="relative z-10 mt-10">
                    <h3 className="font-display text-xl font-semibold text-white">
                      {cat.name}
                    </h3>
                    <p className="mt-1.5 text-sm text-white/50">
                      {cat.description}
                    </p>
                    <p className="mt-4 text-xs font-medium text-electric-bright">
                      {cat.count} products
                    </p>
                  </div>
                </a>
              </Reveal>
            );
          })}
        </div>
      </div>
    </section>
  );
}
